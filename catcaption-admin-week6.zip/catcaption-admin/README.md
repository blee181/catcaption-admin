# CATCAPTION Admin — Week 6

Standalone protected admin panel for the CATCAPTION rating app.

## Rubric coverage
- Google login wall for every admin route.
- Database superadmin gate using `profiles.is_superadmin`.
- READ users/profiles.
- CREATE / READ / UPDATE / DELETE AI-generated captions.
- READ upvotes/downvotes.
- Dashboard statistics: profiles, captions, ratings, upvote share, up/down totals, current top caption.

## Setup
1. Run `week6_admin.sql` in Supabase SQL Editor after replacing `YOUR_EMAIL_HERE`.
2. Create a new GitHub repository and push this folder as its root.
3. Create a new Vercel project from that repo.
4. Add env vars from `.env.example` using the same Supabase project as the main app.
5. Add `https://YOUR-ADMIN-PROJECT.vercel.app/auth/callback` to Supabase Auth > URL Configuration > Redirect URLs.
6. Turn Vercel Deployment Protection off.
7. Sign in with the superadmin Google account and test profile read, caption create/update/delete, and ratings read.
